import java.util.List;

// possible idea for factory who constructs the GameObjects
// in a selected level of the game.  This could be subclassed
// but might be best to have a text file that represents a 
// level and that text file can be read in and the objects in 
// the file
public class LevelReader {
	
	
	public static List<List<Obstacle>> readInLevel(int i) {
		
		
		
		return null;
	}

}
